import program as prog
import experiment as exp

def main():
    # experiment = exp.Experiment()
    program = prog.Program()
    program.run()   

if __name__ == "__main__":
    main()